import { useState } from 'react';
import './Modal.css'
function Modal(props){
    const [input,setInput] = useState('');
    const [category,setCategory] = useState('Dev-Tasks');
    return(
        <div className='modal-back'>
        <div className='column align-center justify-center text-left default-color modal'>
            <div className='row align-center justify-between title'>
            <h3>Content</h3>
            <input className='default-color' type="text" value={input} onChange={(e)=>setInput(e.target.value)}/>
            </div>
            <div className='dropdown'>
                <select className='default-color ' value={category} onChange={(e)=>setCategory(e.target.value)}>
                    {props.categories.map((el,index)=>{
                        return(
                            <option key={el} value={el}>{el}</option>
                        )
                    })}
                </select>
            </div>
            <button onClick={()=>props.pushData(input,category)}>Add Card</button>
            <button onClick={()=>props.toggleModal()}>Close Modal</button>
        </div>
        </div>
    );
}
export default Modal;