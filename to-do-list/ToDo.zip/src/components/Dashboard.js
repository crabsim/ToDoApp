import React,{useState,useEffect} from 'react';
import './Dashboard.css';
import CreateModal from './CreateModal';
import Cards from './Cards';
import Modal  from './Modal';
function Dashboard(){
    
   
    const categories = ["Dev-Tasks","Updates-Push","Updates-Pull","Prod-Issue","Code-Review","Meetings"];
    let [count,setCount] = useState(0);
    let [cardsData,setCards] = useState(getLocalCards());
    let [modalVisible,setModal] = useState(false);

    function toggleModal(){
        setModal(!modalVisible);
    }
    function getLocalCards(){
        if(localStorage.getItem("cardsData") ==  undefined){
            return [];
        }
        else{
            return JSON.parse(localStorage.getItem("cardsData"));
        }
    }
    const pushData = (title,category) =>{
        setCards([...cardsData, {id:count, title:title, category:category}]);
        setCount(count+1);
        toggleModal();
    }
    const clearAll = () =>{
        setCards([]);
    }
    const deleteCard = (index) =>{
        const updatedData = cardsData.filter((el,i) => {return i!=index});
        setCards(updatedData);
    }

    useEffect(() =>{
        localStorage.setItem('cardsData',JSON.stringify(cardsData));
    },[cardsData])
    // useEffect(()=>{
    //     console.log(modalVisible);
    // },[modalVisible])

        return(
            <div className='column align-center width-100 dash-container'>
                <CreateModal toggleModal={toggleModal} clearAll={clearAll}/>
                <Cards deleteCard={deleteCard} categories={categories} cardsData={cardsData}  />
                {modalVisible ? <Modal categories={categories} pushData={pushData} toggleModal={toggleModal} /> : null}
            </div>
        )
}

export default Dashboard;