import './Card.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faTrashCan} from '@fortawesome/free-solid-svg-icons'

function Card(props){
    //console.log(props.data);
    return(
        <div className="card">
            <div className='row align-center justify-between default-color border-box width-100  card-content'>
            <div className='row align-center card-update'>
            <input type="checkbox" className="checkbox"/>
            <span className="checkbox"></span>
            <h3>{props.data.title}</h3>
            </div>
            <div className='card-delete'>
            <FontAwesomeIcon className='delete-icon' icon={faTrashCan} onClick={()=>{props.deleteCard(props.index)}} />
            </div>
            </div>
        </div>
    );
}
export default Card;