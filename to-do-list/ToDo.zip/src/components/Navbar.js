import React,{Component} from 'react';
import './Navbar.css';

class Navbar extends Component{
    render(){
        return(
            <div className="default-color navbar">
                <h2>Todo List Manager</h2>
            </div>
        )
    }
}

export default Navbar;