import Navbar from './components/Navbar';
import './App.css';
import Dashboard from './components/Dashboard';
function App() {
  return (
    <>
      <Navbar />
      <Dashboard />
    </>
  );
}

export default App;
